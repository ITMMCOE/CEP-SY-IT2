<?php
$host = "localhost";
$user = "root";
$pass = ""; // keep empty for XAMPP
$db   = "saf_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
