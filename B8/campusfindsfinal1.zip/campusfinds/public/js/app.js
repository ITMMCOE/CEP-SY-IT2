// public/js/app.js (Correct and Complete)

document.addEventListener('DOMContentLoaded', () => {
    const path = window.location.pathname;
    updateNav();

    if (path.endsWith('login.html')) initLoginPage();
    else if (path.endsWith('register.html')) initRegisterPage();
    else if (path.endsWith('admin_register.html')) initAdminRegisterPage();
    else if (path.endsWith('dashboard_student.html')) initStudentDashboard();
    else if (path.endsWith('dashboard_admin.html')) initAdminDashboard();
    else if (path.endsWith('post_lost.html')) initPostItemPage();
    else if (path.endsWith('view_item.html')) initViewItemPage();
    else initIndexPage(); // Default to index page
});

// --- COMMON FUNCTIONS ---
async function updateNav() {
    const navLinksContainer = document.getElementById('nav-links');
    if (!navLinksContainer) return;
    try {
        const response = await fetch('/api/user');
        if (response.ok) {
            const user = await response.json();
            const dashboardLink = user.role === 'admin' ? '/public/dashboard_admin.html' : '/public/dashboard_student.html';
            navLinksContainer.innerHTML = `
                <a href="${dashboardLink}" class="text-gray-300 hover:text-white mr-4">Dashboard</a>
                <button id="logout-btn" class="bg-accent-rosy hover:bg-opacity-80 text-white font-bold py-2 px-4 rounded">Logout</button>
            `;
            document.getElementById('logout-btn').addEventListener('click', handleLogout);
        } else {
             navLinksContainer.innerHTML = `
                <a href="/public/login.html" class="text-gray-300 hover:text-white mr-4">Login</a>
                <a href="/public/register.html" class="text-dark-primary bg-accent-gold hover:bg-yellow-400 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Register</a>
            `;
        }
    } catch (error) { console.error('Error checking auth status:', error); }
}

async function handleLogout() {
    await fetch('/api/logout');
    window.location.href = '/public/login.html';
}

function createItemCard(item) {
    const statusLabel = item.is_lost ? 'LOST' : 'FOUND';
    const statusColor = item.is_lost ? 'bg-accent-rosy' : 'bg-green-600';
    const resolvedLabel = item.resolved ? '<span class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-800 bg-green-200">RECLAIMED</span>' : '';
    return `
        <div class="bg-card-bg/40 rounded-lg shadow-lg overflow-hidden transition-transform transform hover:-translate-y-1 border border-accent-magenta/50">
            <img src="${item.image_path || 'https://via.placeholder.com/400x250.png?text=No+Image'}" alt="${item.title}" class="w-full h-48 object-cover">
            <div class="p-4">
                <div class="flex justify-between items-center mb-2">
                    <span class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-white ${statusColor}">${statusLabel}</span>
                    ${resolvedLabel}
                </div>
                <h3 class="font-bold text-lg text-white mb-2 truncate">${item.title}</h3>
                <p class="text-gray-400 text-sm mb-1"><span class="font-semibold">Location:</span> ${item.location}</p>
                <p class="text-gray-400 text-sm mb-4"><span class="font-semibold">Date:</span> ${new Date(item.date_lost_found).toLocaleDateString()}</p>
                <a href="/public/view_item.html?id=${item.id}" class="w-full text-center block bg-accent-magenta hover:bg-opacity-80 text-white font-bold py-2 px-4 rounded">View Details</a>
            </div>
        </div>
    `;
}

// --- PAGE-SPECIFIC INITIALIZATION ---

function initIndexPage() {
    const searchForm = document.getElementById('search-form');
    const itemsGrid = document.getElementById('items-grid');
    const noItemsMsg = document.getElementById('no-items-message');
    async function fetchAndDisplayItems(query = '') {
        try {
            const response = await fetch(`/api/items${query}`);
            const items = await response.json();
            itemsGrid.innerHTML = '';
            if (items.length === 0) noItemsMsg.style.display = 'block';
            else {
                noItemsMsg.style.display = 'none';
                items.forEach(item => itemsGrid.innerHTML += createItemCard(item));
            }
        } catch (error) {
            console.error('Failed to fetch items:', error);
            itemsGrid.innerHTML = '<p class="text-red-500">Could not load items.</p>';
        }
    }
    if (searchForm) {
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const params = new URLSearchParams(new FormData(searchForm));
            fetchAndDisplayItems(`?${params.toString()}`);
        });
    }
    fetchAndDisplayItems();
}

function initLoginPage() {
    const loginForm = document.getElementById('login-form');
    const errorMessage = document.getElementById('error-message');
    if (!loginForm) return;
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        errorMessage.textContent = '';
        const data = Object.fromEntries(new FormData(loginForm).entries());
        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });
            const result = await response.json();
            if (response.ok) {
                window.location.href = result.user.role === 'admin' ? '/public/dashboard_admin.html' : '/public/dashboard_student.html';
            } else {
                errorMessage.textContent = result.message || 'Login failed.';
            }
        } catch (error) {
            errorMessage.textContent = 'An error occurred. Please try again.';
        }
    });
}

function initRegisterPage() {
    const registerForm = document.getElementById('register-form');
    const messageDiv = document.getElementById('message');
    if (!registerForm) return;
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        messageDiv.textContent = '';
        messageDiv.className = 'text-sm text-center';
        const data = Object.fromEntries(new FormData(registerForm).entries());
        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });
            const result = await response.json();
            if (response.ok) {
                messageDiv.textContent = 'Registration successful! Redirecting to login...';
                messageDiv.classList.add('text-green-400');
                setTimeout(() => window.location.href = '/public/login.html', 2000);
            } else {
                messageDiv.textContent = result.message || 'Registration failed.';
                messageDiv.classList.add('text-red-400');
            }
        } catch (error) {
            messageDiv.textContent = 'An error occurred. Please try again.';
            messageDiv.classList.add('text-red-400');
        }
    });
}


function initAdminRegisterPage() {
    const form = document.getElementById('admin-register-form');
    const msgDiv = document.getElementById('message');
    if (!form) return;
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        msgDiv.textContent = '';
        msgDiv.className = 'text-sm text-center';
        const data = Object.fromEntries(new FormData(form).entries());
        try {
            const res = await fetch('/api/admin/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });
            const result = await res.json();
            if (res.ok) {
                msgDiv.textContent = 'Registration successful! Your account is pending approval.';
                msgDiv.classList.add('text-green-400');
                form.reset();
            } else {
                msgDiv.textContent = result.message || 'Registration failed.';
                msgDiv.classList.add('text-red-400');
            }
        } catch (err) {
            msgDiv.textContent = 'An error occurred.';
            msgDiv.classList.add('text-red-400');
        }
    });
}

async function initStudentDashboard() {
    const myItemsGrid = document.getElementById('my-items-grid');
    const unresolvedItemsGrid = document.getElementById('unresolved-items-grid');
    const noMyItemsMsg = document.getElementById('no-my-items-message');
    const noUnresolvedItemsMsg = document.getElementById('no-unresolved-items-message');
    try {
        const res = await fetch('/api/myitems');
        if(!res.ok) { if(res.status === 401) window.location.href = '/public/login.html'; return; }
        const myItems = await res.json();
        if (myItems.length === 0) noMyItemsMsg.style.display = 'block';
        else myItems.forEach(item => myItemsGrid.innerHTML += createItemCard(item));
    } catch(err) { console.error("Error fetching my items:", err); }
    try {
        const res = await fetch('/api/items?type=lost&resolved=0');
        const unresolvedItems = await res.json();
        if (unresolvedItems.length === 0) noUnresolvedItemsMsg.style.display = 'block';
        else unresolvedItems.forEach(item => unresolvedItemsGrid.innerHTML += createItemCard(item));
    } catch(err) { console.error("Error fetching unresolved items:", err); }
}

async function initAdminDashboard() {
    const tableBody = document.getElementById('admin-items-table-body');
    const noItemsMsg = document.getElementById('no-items-message');
    const statsSection = document.getElementById('stats-section');
    const pendingAdminsTbody = document.getElementById('pending-admins-tbody');
    const noPendingAdminsMsg = document.getElementById('no-pending-admins-msg');

    try {
        const res = await fetch('/api/admin/stats');
        if(!res.ok) { if(res.status === 401 || res.status === 403) window.location.href = '/public/login.html'; return; }
        const stats = await res.json();
        statsSection.innerHTML = `
            <div class="bg-card-bg/50 p-6 rounded-lg border border-accent-magenta"><h4 class="text-gray-400 text-sm font-medium">Total Students</h4><p class="text-3xl font-bold text-white">${stats.totalStudents}</p></div>
            <div class="bg-card-bg/50 p-6 rounded-lg border border-accent-magenta"><h4 class="text-gray-400 text-sm font-medium">Total Items Reported</h4><p class="text-3xl font-bold text-white">${stats.totalItems}</p></div>
            <div class="bg-card-bg/50 p-6 rounded-lg border border-accent-magenta"><h4 class="text-gray-400 text-sm font-medium">Items Reclaimed</h4><p class="text-3xl font-bold text-white">${stats.resolvedItems}</p></div>
        `;
    } catch(err) { console.error("Error fetching stats:", err); }

    try {
        const res = await fetch('/api/admin/pending');
        const pendingAdmins = await res.json();
        if (pendingAdmins.length === 0) noPendingAdminsMsg.style.display = 'block';
        else {
            pendingAdminsTbody.innerHTML = pendingAdmins.map(admin => `
                <tr class="bg-dark-primary border-b border-accent-magenta/50 hover:bg-card-bg/30">
                    <td class="py-4 px-6">${admin.name}</td>
                    <td class="py-4 px-6">${admin.email}</td>
                    <td class="py-4 px-6">${new Date(admin.created_at).toLocaleDateString()}</td>
                    <td class="py-4 px-6"><button onclick="handleApproveAdmin(${admin.id}, this)" class="font-medium text-green-400 hover:underline">Approve</button></td>
                </tr>
            `).join('');
        }
    } catch(err) { console.error("Error fetching pending admins:", err); }

    try {
        const res = await fetch('/api/items');
        const items = await res.json();
        if (items.length === 0) noItemsMsg.style.display = 'block';
        else {
            tableBody.innerHTML = items.map(item => `
                <tr class="bg-dark-primary border-b border-accent-magenta/50 hover:bg-card-bg/30">
                    <th scope="row" class="py-4 px-6 font-medium text-white whitespace-nowrap"><a href="/public/view_item.html?id=${item.id}" class="hover:underline">${item.title}</a></th>
                    <td class="py-4 px-6">${item.category}</td>
                    <td class="py-4 px-6">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.is_lost ? 'bg-accent-rosy text-white' : 'bg-blue-300 text-blue-800'}">${item.is_lost ? 'Lost' : 'Found'}</span>
                        <span class="ml-2 px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.resolved ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'}">${item.resolved ? 'Resolved' : 'Pending'}</span>
                    </td>
                    <td class="py-4 px-6">${item.userName}</td>
                    <td class="py-4 px-6">${new Date(item.created_at).toLocaleDateString()}</td>
                    <td class="py-4 px-6">
                        <button onclick="handleResolveItem(${item.id}, this)" class="font-medium text-green-400 hover:underline mr-3" ${item.resolved ? 'disabled' : ''}>Resolve</button>
                        <button onclick="handleDeleteItem(${item.id}, this)" class="font-medium text-accent-rosy hover:underline">Delete</button>
                    </td>
                </tr>`).join('');
        }
    } catch(err) { console.error("Error fetching all items:", err); }
}

async function initPostItemPage() {
    const postItemForm = document.getElementById('post-item-form');
    const messageDiv = document.getElementById('message');
    if(!postItemForm) return;
    postItemForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        messageDiv.textContent = '';
        messageDiv.className = 'text-sm text-center';
        try {
            const response = await fetch('/api/items', { method: 'POST', body: new FormData(postItemForm) });
            if (response.ok) {
                messageDiv.textContent = 'Item posted successfully! Redirecting...';
                messageDiv.classList.add('text-green-400');
                setTimeout(() => window.location.href = '/public/dashboard_student.html', 2000);
            } else {
                if(response.status === 401) {
                    messageDiv.textContent = 'You must be logged in. Redirecting...';
                    setTimeout(() => window.location.href = '/public/login.html', 2000);
                } else {
                    messageDiv.textContent = (await response.json()).message || 'Failed to post item.';
                }
                messageDiv.classList.add('text-red-400');
            }
        } catch (error) {
            messageDiv.textContent = 'An error occurred.';
            messageDiv.classList.add('text-red-400');
        }
    });
}

async function initViewItemPage() {
    const container = document.getElementById('item-details-container');
    const itemId = new URLSearchParams(window.location.search).get('id');
    if (!itemId) { container.innerHTML = '<p class="text-red-500 text-center">No item ID provided.</p>'; return; }
    try {
        const [itemRes, userRes] = await Promise.all([fetch(`/api/items/${itemId}`), fetch('/api/user')]);
        const item = await itemRes.json();
        const user = userRes.ok ? await userRes.json() : null;
        if (!itemRes.ok) { container.innerHTML = `<p class="text-red-500 text-center">${item.message || 'Item not found.'}</p>`; return; }

        const isOwner = user && user.id === item.user_id;
        const isAdmin = user && user.role === 'admin';
        
        let actionButtons = '';
        if (user && !isOwner && item.is_lost && !item.resolved) {
            actionButtons += `<button onclick="handleClaimItem(${item.id})" class="bg-accent-gold hover:bg-yellow-400 text-dark-primary font-bold py-2 px-4 rounded mr-2">I Found This!</button>`;
        }
        if ((isOwner || isAdmin) && !item.resolved) {
             actionButtons += `<button onclick="handleResolveItem(${item.id})" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mr-2">Mark as Reclaimed</button>`;
        }
        if (isOwner || isAdmin) {
             actionButtons += `<button onclick="handleDeleteItem(${item.id})" class="bg-accent-rosy hover:bg-opacity-80 text-white font-bold py-2 px-4 rounded">Delete Item</button>`;
        }
        
        let foundByInfo = item.foundByUserName ? `<p><strong class="text-gray-400 w-32 inline-block">Found by:</strong> ${item.foundByUserName}</p>` : '';
        container.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div><img src="${item.image_path || 'https://via.placeholder.com/600x400.png?text=No+Image'}" alt="${item.title}" class="w-full h-auto rounded-lg shadow-lg"></div>
                <div>
                    <span class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-white ${item.is_lost ? 'bg-accent-rosy' : 'bg-green-600'} mb-2">${item.is_lost ? 'Lost Item' : 'Found Item'}</span>
                    ${item.resolved ? '<span class="ml-2 text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-800 bg-green-200">RECLAIMED</span>' : ''}
                    <h1 class="text-4xl font-bold mb-4 text-white">${item.title}</h1>
                    <p class="text-gray-300 mb-6">${item.description || 'No description provided.'}</p>
                    <div class="space-y-3 text-lg">
                        <p><strong class="text-gray-400 w-32 inline-block">Category:</strong> ${item.category}</p>
                        <p><strong class="text-gray-400 w-32 inline-block">Location:</strong> ${item.location}</p>
                        <p><strong class="text-gray-400 w-32 inline-block">Date:</strong> ${new Date(item.date_lost_found).toLocaleDateString()}</p>
                        <p><strong class="text-gray-400 w-32 inline-block">Contact:</strong> <a href="mailto:${item.contact}" class="text-accent-gold hover:underline">${item.contact}</a></p>
                        <p><strong class="text-gray-400 w-32 inline-block">Posted by:</strong> ${item.userName}</p>
                        ${foundByInfo}
                    </div>
                    <div class="mt-8">${actionButtons}</div>
                </div>
            </div>`;
    } catch (error) {
        console.error('Error fetching item details:', error);
        container.innerHTML = '<p class="text-red-500 text-center">Failed to load item details.</p>';
    }
}

// --- ACTION HANDLERS ---
async function handleResolveItem(itemId, button) {
    if (confirm('Are you sure you want to mark this item as resolved?')) {
        try {
            const res = await fetch(`/api/items/${itemId}/resolve`, { method: 'PUT' });
            if (res.ok) {
                alert('Item marked as resolved!');
                if(button) {
                    button.disabled = true;
                    button.textContent = 'Resolved';
                    const statusCell = button.closest('tr').children[2];
                    statusCell.querySelector('.bg-yellow-200').textContent = 'Resolved';
                    statusCell.querySelector('.bg-yellow-200').classList.replace('bg-yellow-200', 'bg-green-200');
                    statusCell.querySelector('.text-yellow-800').classList.replace('text-yellow-800', 'text-green-800');
                } else window.location.reload();
            } else alert(`Error: ${(await res.json()).message}`);
        } catch(err) { alert('An error occurred.'); }
    }
}

async function handleDeleteItem(itemId, button) {
    if (confirm('Are you sure you want to permanently delete this item?')) {
        try {
            const res = await fetch(`/api/items/${itemId}`, { method: 'DELETE' });
            if (res.ok) {
                alert('Item deleted successfully!');
                if(button) button.closest('tr').remove();
                else window.location.href = '/';
            } else alert(`Error: ${(await res.json()).message}`);
        } catch(err) { alert('An error occurred.'); }
    }
}

async function handleApproveAdmin(userId, button) {
    if (confirm('Are you sure you want to approve this admin?')) {
        try {
            const res = await fetch(`/api/admin/approve/${userId}`, { method: 'PUT' });
            if (res.ok) {
                alert('Admin approved!');
                button.closest('tr').remove();
            } else { alert(`Error: ${(await res.json()).message}`); }
        } catch(err) { alert('An error occurred.'); }
    }
}

async function handleClaimItem(itemId) {
    if (confirm('Are you confirming you have found this item? This will notify the owner.')) {
        try {
            const res = await fetch(`/api/items/${itemId}/claim`, { method: 'PUT' });
            if (res.ok) {
                alert('Success! The item is now marked as found.');
                window.location.reload();
            } else { alert(`Error: ${(await res.json()).message}`); }
        } catch(err) { alert('An error occurred.'); }
    }
}