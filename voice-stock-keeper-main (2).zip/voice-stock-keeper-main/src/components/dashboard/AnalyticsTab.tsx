import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Brain, TrendingDown, AlertTriangle, Download, RefreshCw, TrendingUp, Package, DollarSign } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/integrations/supabase/auth';
import { supabase } from '@/integrations/supabase/client';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface Prediction {
  item: string;
  currentStock: number;
  daysUntilEmpty: number;
  confidence: number;
  suggestedRestock: number;
  restockBy: string;
}

interface Anomaly {
  type: 'spike' | 'drop' | 'unusual_pattern';
  item: string;
  description: string;
  timestamp: string;
  severity: 'low' | 'medium' | 'high';
}

interface DailyTrend {
  date: string;
  totalSales: number;
  transactions: number;
  avgSaleValue: number;
}

interface ProductTrend {
  product: string;
  totalQuantity: number;
  totalRevenue: number;
}

interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
}

const LOW_STOCK_THRESHOLD = 5;

const AnalyticsTab = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [dailyTrends, setDailyTrends] = useState<DailyTrend[]>([]);
  const [topProducts, setTopProducts] = useState<ProductTrend[]>([]);
  const [loading, setLoading] = useState(false);
  const [smartPredictionsEnabled, setSmartPredictionsEnabled] = useState(true);
  const [lowStock, setLowStock] = useState<InventoryItem[]>([]);
  const prevLowCountRef = useRef(0);

  const loadAnalytics = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const inventory = JSON.parse(localStorage.getItem(`inventory_${user.id}`) || '[]');
      const salesHistory = JSON.parse(localStorage.getItem(`sales_${user.id}`) || '[]');

      if (salesHistory.length < 5) {
        toast({
          title: 'Insufficient data',
          description: 'Record at least 5 sales to see AI insights',
          variant: 'destructive'
        });
        setLoading(false);
        return;
      }

      // Call predictions endpoint
      const { data: predData, error: predError } = await supabase.functions.invoke('analytics-predictions', {
        body: { salesHistory, inventory }
      });

      if (predError) throw predError;
      setPredictions(predData.predictions || []);

      // Call anomalies endpoint
      const { data: anomData, error: anomError } = await supabase.functions.invoke('analytics-anomalies', {
        body: { salesHistory }
      });

      if (anomError) throw anomError;
      setAnomalies(anomData.anomalies || []);

      // Call trends endpoint
      const { data: trendData, error: trendError } = await supabase.functions.invoke('analytics-trends', {
        body: { salesHistory }
      });

      if (trendError) throw trendError;
      setDailyTrends(trendData.dailyTrends || []);
      setTopProducts(trendData.topProducts || []);

      toast({ title: 'Analytics updated', description: 'AI insights generated successfully' });
    } catch (error) {
      console.error('Analytics error:', error);
      const message = error instanceof Error ? error.message : 'Please try again';
      toast({
        title: 'Failed to load analytics',
        description: message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user && smartPredictionsEnabled) {
      loadAnalytics();
    }
  }, [user, smartPredictionsEnabled]);

  useEffect(() => {
    if (!user) return;
    const checkLowStock = () => {
      const inventory: InventoryItem[] = JSON.parse(localStorage.getItem(`inventory_${user.id}`) || '[]');
      const low = inventory.filter(i => i.quantity < LOW_STOCK_THRESHOLD);
      setLowStock(low);
      if (low.length > prevLowCountRef.current) {
        const newlyLow = low.slice(prevLowCountRef.current);
        newlyLow.forEach(item => toast({ title: 'Low stock alert', description: `${item.name} has ${item.quantity} left`, variant: 'destructive' }));
      }
      prevLowCountRef.current = low.length;
    };
    checkLowStock();
    const id = setInterval(checkLowStock, 10000);
    return () => clearInterval(id);
  }, [user]);

  const exportToCSV = () => {
    const csvData = [
      ['Item', 'Current Stock', 'Days Until Empty', 'Confidence %', 'Restock By'],
      ...predictions.map(p => [p.item, p.currentStock, p.daysUntilEmpty, p.confidence, p.restockBy])
    ];

    const csv = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();

    toast({ title: 'Report exported', description: 'Analytics data downloaded as CSV' });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-destructive';
      case 'medium': return 'text-orange-500';
      case 'low': return 'text-yellow-500';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <Card className="glass-effect border-primary/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 gradient-primary rounded-xl">
                <Brain className="w-7 h-7 text-white" />
              </div>
              <div>
                <CardTitle className="text-2xl">AI Analytics Dashboard</CardTitle>
                <CardDescription>Sales predictions, anomaly detection & insights</CardDescription>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Label htmlFor="smart-predictions" className="text-sm">Smart Predictions</Label>
                <Switch
                  id="smart-predictions"
                  checked={smartPredictionsEnabled}
                  onCheckedChange={setSmartPredictionsEnabled}
                />
              </div>
              <Button onClick={loadAnalytics} disabled={loading} variant="outline">
                <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button onClick={exportToCSV} disabled={predictions.length === 0} className="gradient-secondary text-white">
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* AI Insights Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="glass-effect hover-lift border-destructive/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingDown className="w-5 h-5 text-destructive" />
              Low Stock Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-destructive">
              {lowStock.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Items below {LOW_STOCK_THRESHOLD} units
            </p>
            {lowStock.length > 0 && (
              <ul className="mt-2 text-sm text-muted-foreground space-y-1">
                {lowStock.slice(0,5).map((i) => (
                  <li key={i.id}>• {i.name} — {i.quantity} left</li>
                ))}
                {lowStock.length > 5 && <li>+ {lowStock.length - 5} more…</li>}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card className="glass-effect hover-lift border-orange-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Package className="w-5 h-5 text-orange-500" />
              Restock Needed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-500">
              {predictions.filter(p => p.daysUntilEmpty < 14).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Items need restocking in 2 weeks
            </p>
          </CardContent>
        </Card>

        <Card className="glass-effect hover-lift border-yellow-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
              Anomalies Detected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-500">
              {anomalies.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Unusual patterns in sales data
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales Trend Chart */}
        <Card className="glass-effect border-secondary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-secondary" />
              Sales Over Time
            </CardTitle>
            <CardDescription>Daily transaction trends</CardDescription>
          </CardHeader>
          <CardContent>
            {dailyTrends.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={dailyTrends}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    tickFormatter={(date) => new Date(date).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="totalSales" 
                    stroke="hsl(var(--secondary))" 
                    strokeWidth={2}
                    name="Total Sales"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="transactions" 
                    stroke="hsl(var(--accent))" 
                    strokeWidth={2}
                    name="Transactions"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                <p>No sales data available</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top Products Chart */}
        <Card className="glass-effect border-accent/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-accent" />
              Top Selling Products
            </CardTitle>
            <CardDescription>Revenue by product</CardDescription>
          </CardHeader>
          <CardContent>
            {topProducts.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={topProducts.slice(0, 5)}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis 
                    dataKey="product" 
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Bar 
                    dataKey="totalRevenue" 
                    fill="hsl(var(--primary))" 
                    name="Revenue (₹)"
                    radius={[8, 8, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                <p>No product data available</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Predictions Table */}
      <Card className="glass-effect border-primary/20">
        <CardHeader>
          <CardTitle>Stock Predictions & Restock Recommendations</CardTitle>
          <CardDescription>AI-powered forecasts based on sales patterns</CardDescription>
        </CardHeader>
        <CardContent>
          {predictions.length > 0 ? (
            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
              {predictions.map((pred, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-xl border-2 bg-gradient-to-r from-card to-muted/20 hover:shadow-elegant transition-all ${
                    pred.daysUntilEmpty < 7 ? 'border-destructive/50' : 'border-border'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <p className="font-bold text-lg">{pred.item}</p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2 text-sm">
                        <div>
                          <span className="text-muted-foreground">Current Stock:</span>
                          <span className="font-semibold ml-1">{pred.currentStock}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Days Left:</span>
                          <span className={`font-semibold ml-1 ${pred.daysUntilEmpty < 7 ? 'text-destructive' : ''}`}>
                            {pred.daysUntilEmpty}
                          </span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Confidence:</span>
                          <span className="font-semibold ml-1 text-secondary">{pred.confidence}%</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Restock:</span>
                          <span className="font-semibold ml-1">{pred.suggestedRestock}</span>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        💡 Based on recent trends, {pred.item} will run out in{' '}
                        <strong>{pred.daysUntilEmpty} days</strong>. Restock by{' '}
                        <strong>{new Date(pred.restockBy).toLocaleDateString('en-IN')}</strong>
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Brain className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">
                {loading ? 'Analyzing sales data...' : 'No predictions available. Record more sales to enable AI insights.'}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Anomalies */}
      {anomalies.length > 0 && (
        <Card className="glass-effect border-yellow-500/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-6 h-6 text-yellow-500" />
              Anomaly Detection
            </CardTitle>
            <CardDescription>Unusual patterns detected in your sales data</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {anomalies.map((anom, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border-2 border-yellow-500/30 bg-gradient-to-r from-yellow-500/5 to-transparent"
                >
                  <div className="flex items-start gap-3">
                    <AlertTriangle className={`w-5 h-5 mt-0.5 ${getSeverityColor(anom.severity)}`} />
                    <div className="flex-1">
                      <p className="font-semibold">{anom.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(anom.timestamp).toLocaleString('en-IN')} • Severity: {anom.severity}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AnalyticsTab;
