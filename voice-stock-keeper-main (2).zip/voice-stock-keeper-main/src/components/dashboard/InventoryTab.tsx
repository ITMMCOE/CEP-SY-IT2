import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Mic, MicOff, Plus, Trash2, Package } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/integrations/supabase/auth';

interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
}

const InventoryTab = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const [lastHeard, setLastHeard] = useState<string>('');
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(true);

  useEffect(() => {
    if (user) {
      const stored = localStorage.getItem(`inventory_${user.id}`);
      if (stored) setItems(JSON.parse(stored));

      const voicePref = localStorage.getItem(`voice_enabled_${user.id}`);
      if (voicePref !== null) setVoiceEnabled(JSON.parse(voicePref));
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(`inventory_${user.id}`, JSON.stringify(items));
      localStorage.setItem(`voice_enabled_${user.id}`, JSON.stringify(voiceEnabled));
    }
  }, [items, voiceEnabled, user]);

  useEffect(() => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) return;

    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    const recognitionInstance = new SpeechRecognition();
    recognitionInstance.continuous = true;
    recognitionInstance.interimResults = true;
    recognitionInstance.lang = navigator.language || 'en-US';

    recognitionInstance.onresult = (event: any) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const transcript = res[0].transcript.toLowerCase().trim();
        if (res.isFinal) {
          setLastHeard(transcript);
          console.info('[Voice] Final:', transcript);
          parseVoiceCommand(transcript);
        }
      }
    };

    recognitionInstance.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        setIsListening(false);
        toast({ title: 'Microphone denied', description: 'Please allow mic access to use voice', variant: 'destructive' });
        return;
      }
      if (isListening && voiceEnabled) {
        // Attempt graceful restart on recoverable errors
        setTimeout(() => recognitionInstance.start(), 400);
      }
    };

    recognitionInstance.onend = () => {
      if (isListening && voiceEnabled) {
        // Auto-restart while listening is enabled
        setTimeout(() => recognitionInstance.start(), 250);
      }
    };

    setRecognition(recognitionInstance);

    return () => {
      try { recognitionInstance.stop(); } catch {}
    };
  }, [isListening, voiceEnabled]);

  const parseVoiceCommand = (raw: string) => {
    const text = raw.toLowerCase().replace(/\bof\b|\bat\b|\bfor\b|\bprice\b|\brupees?\b|\brs\.?\b/g, ' ').replace(/\s+/g, ' ').trim();

    const numberWords: Record<string, number> = {
      zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9,
      ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19,
      twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90,
      hundred: 100
    };

    const toNumber = (token: string | undefined): number | null => {
      if (!token) return null;
      if (/^\d+$/.test(token)) return parseInt(token, 10);
      if (numberWords[token] != null) return numberWords[token];
      return null;
    };

    const toNumberFromTokens = (tokens: string[], start: number) => {
      let n = toNumber(tokens[start]);
      if (n == null) return { value: null as number | null, next: start };
      // handle composite like "twenty five"
      if (n >= 20 && n % 10 === 0 && numberWords[tokens[start + 1]] && numberWords[tokens[start + 1]] < 10) {
        n += numberWords[tokens[start + 1]];
        return { value: n, next: start + 2 };
      }
      return { value: n, next: start + 1 };
    };

    const singularize = (s: string) => s.replace(/ies$/, 'y').replace(/s$/, '');

    const findItemIndex = (nameQuery: string) => {
      const q = singularize(nameQuery.trim());
      return items.findIndex(i => singularize(i.name.toLowerCase()).includes(q));
    };

    const tokens = text.split(' ').filter(Boolean);

    const has = (...arr: string[]) => arr.some(a => tokens.includes(a));

    // 1) Set price commands: "set price of apple to 50", "price apple 40"
    const priceIdx = tokens.findIndex(t => t === 'price');
    if (priceIdx !== -1 || (tokens[0] === 'set' && tokens[1] === 'price')) {
      // locate 'to' or take last number as price
      const toIdx = tokens.indexOf('to');
      const lastNumIdx = [...tokens].map((t, i) => (/^\d+$/.test(t) || numberWords[t] != null) ? i : -1).filter(i => i !== -1).pop();
      const priceVal = lastNumIdx != null ? (toNumber(tokens[lastNumIdx]) as number) : null;
      // product name is tokens between 'price' and number/to
      let start = priceIdx !== -1 ? priceIdx + 1 : 2;
      let end = toIdx !== -1 ? toIdx : (lastNumIdx != null ? lastNumIdx : tokens.length);
      const nameQuery = tokens.slice(start, end).join(' ').trim();
      if (!nameQuery || priceVal == null) {
        toast({ title: 'Price command not recognized', description: 'Try: "set price of apple to 50"', variant: 'destructive' });
        return;
      }
      const idx = findItemIndex(nameQuery);
      if (idx === -1) {
        // create item with price only
        const newItem: InventoryItem = { id: Date.now().toString(), name: nameQuery, quantity: 0, price: priceVal };
        setItems(prev => [...prev, newItem]);
        toast({ title: 'Price set', description: `Created ${newItem.name} with price ₹${priceVal}` });
      } else {
        setItems(prev => prev.map((it, i) => i === idx ? { ...it, price: priceVal } : it));
        toast({ title: 'Price updated', description: `${items[idx].name} → ₹${priceVal}` });
      }
      return;
    }

    // 2) Add / Remove / Update quantities
    const verbIdx = tokens.findIndex(t => ['add', 'insert', 'create', 'plus', 'remove', 'delete', 'minus', 'update', 'set'].includes(t));
    if (verbIdx === -1) {
      toast({ title: 'Command not recognized', description: 'Try: "add 10 apples" or "remove 2 oranges"', variant: 'destructive' });
      return;
    }

    const verb = tokens[verbIdx];

    // Support pattern: verb quantity item OR verb item quantity OR verb item quantity 10 (with word 'quantity' token)
    let qty: number | null = null;
    let nameQuery = '';

    // case: verb quantity item
    const { value: firstNum, next: afterNum } = toNumberFromTokens(tokens, verbIdx + 1);
    if (firstNum != null) {
      qty = firstNum;
      nameQuery = tokens.slice(afterNum).join(' ');
    } else {
      // case: verb item [quantity|qty] N OR trailing number
      const quantityWordIdx = tokens.indexOf('quantity', verbIdx + 1) !== -1 ? tokens.indexOf('quantity', verbIdx + 1) : tokens.indexOf('qty', verbIdx + 1);
      if (quantityWordIdx !== -1) {
        nameQuery = tokens.slice(verbIdx + 1, quantityWordIdx).join(' ');
        const n = toNumberFromTokens(tokens, quantityWordIdx + 1);
        qty = n.value;
      } else {
        // trailing number
        const lastNumIdx = [...tokens].map((t, i) => (/^\d+$/.test(t) || numberWords[t] != null) ? i : -1).filter(i => i !== -1).pop();
        if (lastNumIdx != null && lastNumIdx > verbIdx) {
          qty = toNumber(tokens[lastNumIdx]);
          nameQuery = tokens.slice(verbIdx + 1, lastNumIdx).join(' ');
        }
      }
    }

    nameQuery = nameQuery.trim();
    if (!nameQuery) {
      toast({ title: 'Item not recognized', description: 'Say the product name', variant: 'destructive' });
      return;
    }

    const idx = findItemIndex(nameQuery);

    const applyAdd = (index: number, quantity: number) => {
      if (index === -1) {
        const newItem: InventoryItem = { id: Date.now().toString(), name: nameQuery, quantity, price: 0 };
        setItems(prev => [...prev, newItem]);
      } else {
        setItems(prev => prev.map((it, i) => i === index ? { ...it, quantity: it.quantity + quantity } : it));
      }
      toast({ title: 'Added', description: `${quantity} ${nameQuery}` });
    };

    const applyRemove = (index: number, quantity: number) => {
      if (index === -1) {
        toast({ title: 'Item not found', description: nameQuery, variant: 'destructive' });
        return;
      }
      setItems(prev => prev.map((it, i) => i === index ? { ...it, quantity: Math.max(0, it.quantity - quantity) } : it));
      toast({ title: 'Removed', description: `${quantity} ${nameQuery}` });
    };

    const applyUpdate = (index: number, quantity: number) => {
      if (index === -1) {
        const newItem: InventoryItem = { id: Date.now().toString(), name: nameQuery, quantity, price: 0 };
        setItems(prev => [...prev, newItem]);
        toast({ title: 'Created', description: `${nameQuery} → qty ${quantity}` });
        return;
      }
      setItems(prev => prev.map((it, i) => i === index ? { ...it, quantity } : it));
      toast({ title: 'Updated', description: `${nameQuery} → qty ${quantity}` });
    };

    if (!qty || qty <= 0) {
      toast({ title: 'Quantity not recognized', description: 'Say a valid quantity', variant: 'destructive' });
      return;
    }

    if (['add', 'insert', 'create', 'plus'].includes(verb)) return applyAdd(idx, qty);
    if (['remove', 'delete', 'minus'].includes(verb)) return applyRemove(idx, qty);
    if (['update', 'set'].includes(verb)) return applyUpdate(idx, qty);

    toast({ title: 'Command not recognized', description: 'Try: "add 10 apples"', variant: 'destructive' });
  };

  const toggleVoiceInput = async () => {
    if (!voiceEnabled) {
      toast({ title: 'Voice is disabled', description: 'Enable voice control in settings', variant: 'destructive' });
      return;
    }
    if (!recognition) {
      toast({ title: 'Voice not supported', description: 'Your browser does not support voice input', variant: 'destructive' });
      return;
    }

    if (isListening) {
      try { recognition.stop(); } catch {}
      setIsListening(false);
    } else {
      try {
        if (navigator.mediaDevices?.getUserMedia) {
          await navigator.mediaDevices.getUserMedia({ audio: true });
        }
      } catch (e) {
        toast({ title: 'Microphone blocked', description: 'Please allow mic access to use voice', variant: 'destructive' });
        return;
      }
      try { recognition.start(); } catch {}
      setIsListening(true);
      toast({ title: 'Listening…', description: 'Try: "add 10 apples", "remove 2 oranges", "set price of apple to 50"' });
    }
  };

  const addItem = () => {
    if (!name || !quantity || !price) {
      toast({ title: 'Missing fields', description: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    const newItem: InventoryItem = {
      id: Date.now().toString(),
      name,
      quantity: parseInt(quantity),
      price: parseInt(price)
    };

    setItems(prev => [...prev, newItem]);
    setName('');
    setQuantity('');
    setPrice('');
    toast({ title: 'Item added', description: `${newItem.quantity} ${newItem.name} at ₹${newItem.price}` });
  };

  const deleteItem = (id: string) => {
    setItems(prev => prev.filter(item => item.id !== id));
    toast({ title: 'Item removed' });
  };

  return (
    <>
      <Card className="glass-effect hover-lift border-primary/20">
        <CardHeader className="bg-gradient-to-r from-primary/10 via-accent/10 to-transparent">
          <CardTitle className="flex items-center gap-2 text-xl">
            <Plus className="w-6 h-6 text-primary" />
            Add Inventory
          </CardTitle>
          <CardDescription>Add items manually or use voice commands</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Label htmlFor="voice-enabled" className="text-sm">Voice control</Label>
              <Switch
                id="voice-enabled"
                checked={voiceEnabled}
                onCheckedChange={(v) => {
                  setVoiceEnabled(v);
                  if (!v && isListening) { try { recognition?.stop(); } catch {} setIsListening(false); }
                }}
                aria-label="Enable voice control"
              />
              <span className="text-xs text-muted-foreground">{voiceEnabled ? 'On' : 'Off'}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 mt-2">
            <Button
              onClick={toggleVoiceInput}
              disabled={!voiceEnabled}
              variant={isListening ? 'destructive' : 'default'}
              className={`w-full sm:w-auto shadow-elegant ${isListening ? 'pulse shadow-glow' : ''}`}
            >
              {isListening ? <MicOff className="w-5 h-5 mr-2" /> : <Mic className="w-5 h-5 mr-2" />}
              {isListening ? 'Stop Voice Input' : 'Start Voice Input'}
            </Button>
            {isListening && (
              <div className="flex items-center gap-2 text-primary">
                <div className="w-3 h-3 rounded-full bg-primary shadow-glow pulse" />
                <span className="text-sm">Listening…</span>
              </div>
            )}
          </div>
          {lastHeard && <p className="text-xs text-muted-foreground mt-1">Heard: "{lastHeard}"</p>}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-semibold">Product Name</Label>
              <Input
                id="name"
                placeholder="e.g., Pen"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="border-2 focus:border-primary transition-colors"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="quantity" className="text-sm font-semibold">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                placeholder="e.g., 20"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="border-2 focus:border-primary transition-colors"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price" className="text-sm font-semibold">Price (₹)</Label>
              <Input
                id="price"
                type="number"
                placeholder="e.g., 10"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="border-2 focus:border-primary transition-colors"
              />
            </div>
          </div>

          <Button onClick={addItem} className="w-full gradient-primary text-white shadow-glow hover:scale-105 transition-transform">
            <Plus className="w-5 h-5 mr-2" />
            Add Item to Inventory
          </Button>
        </CardContent>
      </Card>

      <Card className="glass-effect hover-lift border-secondary/20">
        <CardHeader className="bg-gradient-to-r from-secondary/10 to-transparent">
          <CardTitle className="text-xl">Current Inventory</CardTitle>
          <CardDescription className="text-lg font-semibold text-foreground">{items.length} items in stock</CardDescription>
        </CardHeader>
        <CardContent>
          {items.length === 0 ? (
            <div className="text-center py-12">
              <Package className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No items yet. Add your first item above.</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
              {items.map((item, idx) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-4 rounded-xl border-2 bg-gradient-to-r from-card to-muted/20 hover:shadow-elegant hover:-translate-y-0.5 transition-all duration-300"
                  style={{ animationDelay: `${idx * 0.05}s` }}
                >
                  <div className="flex-1">
                    <p className="font-bold text-lg text-foreground">{item.name}</p>
                    <div className="flex gap-4 mt-1">
                      <p className="text-sm text-muted-foreground font-medium">
                        Qty: <span className="text-primary font-bold">{item.quantity}</span>
                      </p>
                      <p className="text-sm text-muted-foreground font-medium">
                        Price: <span className="text-secondary font-bold">₹{item.price}</span>
                      </p>
                      <p className="text-sm text-muted-foreground font-medium">
                        Total: <span className="text-accent font-bold">₹{item.quantity * item.price}</span>
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => deleteItem(item.id)} className="hover:bg-destructive/10 hover:scale-110 transition-all">
                    <Trash2 className="w-5 h-5 text-destructive" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
};

export default InventoryTab;
