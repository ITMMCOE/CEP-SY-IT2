import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/integrations/supabase/auth';
import { useToast } from '@/hooks/use-toast';
import { User, Save } from 'lucide-react';

interface UserProfile {
  displayName: string;
  businessName: string;
  phone: string;
}

const ProfileTab = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState<UserProfile>({
    displayName: '',
    businessName: '',
    phone: ''
  });

  useEffect(() => {
    if (user) {
      const stored = localStorage.getItem(`profile_${user.id}`);
      if (stored) {
        setProfile(JSON.parse(stored));
      }
    }
  }, [user]);

  const saveProfile = () => {
    if (user) {
      localStorage.setItem(`profile_${user.id}`, JSON.stringify(profile));
      toast({ title: 'Profile saved', description: 'Your profile has been updated' });
    }
  };

  return (
    <Card className="glass-effect hover-lift max-w-2xl mx-auto border-primary/20">
      <CardHeader className="gradient-primary text-white rounded-t-xl">
        <CardTitle className="flex items-center gap-3 text-2xl">
          <User className="w-8 h-8" />
          User Profile
        </CardTitle>
        <CardDescription className="text-white/90">Manage your account information</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        <div className="space-y-2">
          <Label className="text-sm font-semibold">Email (Read-only)</Label>
          <Input 
            value={user?.email || ''} 
            disabled 
            className="bg-muted border-2"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="displayName" className="text-sm font-semibold">Display Name</Label>
          <Input
            id="displayName"
            placeholder="Your name"
            value={profile.displayName}
            onChange={(e) => setProfile({ ...profile, displayName: e.target.value })}
            className="border-2 focus:border-primary transition-colors"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="businessName" className="text-sm font-semibold">Business Name</Label>
          <Input
            id="businessName"
            placeholder="Your business"
            value={profile.businessName}
            onChange={(e) => setProfile({ ...profile, businessName: e.target.value })}
            className="border-2 focus:border-primary transition-colors"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone" className="text-sm font-semibold">Phone Number</Label>
          <Input
            id="phone"
            type="tel"
            placeholder="+91 XXXXXXXXXX"
            value={profile.phone}
            onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
            className="border-2 focus:border-primary transition-colors"
          />
        </div>

        <Button onClick={saveProfile} className="w-full gradient-primary text-white shadow-glow hover:scale-105 transition-transform">
          <Save className="w-5 h-5 mr-2" />
          Save Profile
        </Button>
      </CardContent>
    </Card>
  );
};

export default ProfileTab;
