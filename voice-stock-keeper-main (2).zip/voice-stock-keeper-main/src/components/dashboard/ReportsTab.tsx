import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, FileText } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/integrations/supabase/auth';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface SaleRecord {
  id: string;
  product: string;
  quantity: number;
  price: number;
  total: number;
  timestamp: string;
}

const ReportsTab = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [salesHistory, setSalesHistory] = useState<SaleRecord[]>([]);

  useEffect(() => {
    if (user) {
      const stored = localStorage.getItem(`sales_${user.id}`);
      if (stored) {
        setSalesHistory(JSON.parse(stored));
      }
    }
  }, [user]);

  const downloadPDF = () => {
    if (salesHistory.length === 0) {
      toast({ title: 'No data', description: 'No sales to download', variant: 'destructive' });
      return;
    }

    const todayStr = new Date().toDateString();
    const todaySales = salesHistory.filter(s => new Date(s.timestamp).toDateString() === todayStr);
    if (todaySales.length === 0) {
      toast({ title: 'No data for today', description: 'No transactions recorded today', variant: 'destructive' });
      return;
    }

    const doc = new jsPDF();
    const dateLabel = new Date().toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' });

    doc.setFontSize(20);
    doc.text(`Daily Report – ${dateLabel}`, 14, 22);

    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleString('en-IN')}`, 14, 30);
    doc.text(`Total Transactions: ${todaySales.length}`, 14, 36);

    const totalRevenue = todaySales.reduce((sum, s) => sum + s.total, 0);
    doc.text(`Total Revenue: ₹${totalRevenue}`, 14, 42);

    const tableData = todaySales.map(sale => [
      new Date(sale.timestamp).toLocaleDateString('en-IN'),
      new Date(sale.timestamp).toLocaleTimeString('en-IN'),
      sale.product,
      sale.quantity.toString(),
      `₹${sale.price}`,
      `₹${sale.total}`
    ]);

    autoTable(doc, {
      startY: 50,
      head: [['Date', 'Time', 'Product', 'Qty', 'Price', 'Total']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [34, 197, 94] },
      styles: { fontSize: 9 }
    });

    doc.save(`daily-report-${new Date().toISOString().split('T')[0]}.pdf`);
    toast({ title: 'Downloaded', description: 'Today\'s report downloaded successfully' });
  };

  const groupByDate = () => {
    const grouped: { [key: string]: SaleRecord[] } = {};
    salesHistory.forEach(sale => {
      const date = new Date(sale.timestamp).toLocaleDateString('en-IN');
      if (!grouped[date]) grouped[date] = [];
      grouped[date].push(sale);
    });
    return grouped;
  };

  const dailyGroups = groupByDate();

  return (
    <>
      <Card className="glass-effect hover-lift border-accent/30 shadow-glow">
        <CardHeader className="gradient-accent text-white rounded-t-xl">
          <CardTitle className="text-2xl">Sales Reports</CardTitle>
          <CardDescription className="text-white/90">Download and view your sales history</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <Button onClick={downloadPDF} className="w-full sm:w-auto gradient-primary text-white shadow-glow hover:scale-105 transition-transform">
            <Download className="w-5 h-5 mr-2" />
            Download PDF Report
          </Button>
        </CardContent>
      </Card>

      <Card className="glass-effect hover-lift border-primary/20">
        <CardHeader className="bg-gradient-to-r from-accent/10 to-transparent">
          <CardTitle className="flex items-center gap-3 text-xl">
            <FileText className="w-6 h-6 text-accent" />
            Sales History
          </CardTitle>
          <CardDescription>Daily breakdown of all transactions</CardDescription>
        </CardHeader>
        <CardContent>
          {Object.keys(dailyGroups).length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No sales history available</p>
            </div>
          ) : (
            <div className="space-y-6 max-h-[600px] overflow-y-auto pr-2">
              {Object.entries(dailyGroups).map(([date, sales], idx) => {
                const dayTotal = sales.reduce((sum, s) => sum + s.total, 0);
                return (
                  <div 
                    key={date} 
                    className="space-y-3"
                    style={{ animationDelay: `${idx * 0.05}s` }}
                  >
                    <div className="flex justify-between items-center p-4 gradient-accent text-white rounded-xl shadow-elegant">
                      <h3 className="font-bold text-lg">{date}</h3>
                      <div className="text-right">
                        <p className="text-xs opacity-90">{sales.length} transactions</p>
                        <span className="text-xl font-bold">₹{dayTotal.toLocaleString('en-IN')}</span>
                      </div>
                    </div>
                    <div className="space-y-2 pl-2">
                      {sales.map(sale => (
                        <div key={sale.id} className="flex justify-between items-center p-4 border-2 rounded-xl bg-gradient-to-r from-card to-accent/5 hover:shadow-elegant hover:-translate-y-0.5 transition-all">
                          <div className="flex-1">
                            <p className="font-bold text-lg">{sale.product}</p>
                            <p className="text-sm text-muted-foreground">
                              <span className="font-semibold">{new Date(sale.timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span> • 
                              <span className="font-semibold text-primary"> {sale.quantity} × ₹{sale.price}</span>
                            </p>
                          </div>
                          <span className="font-bold text-xl text-accent">₹{sale.total}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
};

export default ReportsTab;
