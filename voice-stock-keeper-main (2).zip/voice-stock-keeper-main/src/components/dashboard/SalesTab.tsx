import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mic, MicOff, TrendingUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/integrations/supabase/auth';

interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
}

interface SaleRecord {
  id: string;
  product: string;
  quantity: number;
  price: number;
  total: number;
  timestamp: string;
}

const SalesTab = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [salesHistory, setSalesHistory] = useState<SaleRecord[]>([]);
  const [product, setProduct] = useState('');
  const [quantity, setQuantity] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [lastHeard, setLastHeard] = useState('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    if (user) {
      const storedInventory = localStorage.getItem(`inventory_${user.id}`);
      if (storedInventory) {
        setInventory(JSON.parse(storedInventory));
      }
      const storedSales = localStorage.getItem(`sales_${user.id}`);
      if (storedSales) {
        setSalesHistory(JSON.parse(storedSales));
      }
    }
  }, [user]);

  // Always persist per-user sales history
  useEffect(() => {
    if (user) {
      localStorage.setItem(`sales_${user.id}`, JSON.stringify(salesHistory));
    }
  }, [salesHistory, user]);

  // Keep local state in sync with latest saved data when returning to this tab
  useEffect(() => {
    if (!user) return;

    const syncFromStorage = () => {
      const inv = localStorage.getItem(`inventory_${user.id}`);
      if (inv) setInventory(JSON.parse(inv));
      const sal = localStorage.getItem(`sales_${user.id}`);
      if (sal) setSalesHistory(JSON.parse(sal));
    };

    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        syncFromStorage();
      }
    };

    window.addEventListener('focus', syncFromStorage);
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      window.removeEventListener('focus', syncFromStorage);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [user]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  // Helpers for smarter voice parsing and matching
  const numberWords: Record<string, number> = {
    zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9,
    ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16,
    seventeen: 17, eighteen: 18, nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50,
    sixty: 60, seventy: 70, eighty: 80, ninety: 90, hundred: 100
  };

  const toNumber = (token: string): number | null => {
    if (/^\d+$/.test(token)) return parseInt(token, 10);
    return numberWords[token] ?? null;
  };

  const normalizeName = (s: string) => s.toLowerCase().trim().replace(/\s+/g, ' ').replace(/[^a-z0-9\s-]/g, '');
  const singularize = (s: string) => {
    if (s.endsWith('ies')) return s.slice(0, -3) + 'y';
    if (s.endsWith('es')) return s.slice(0, -2);
    if (s.endsWith('s')) return s.slice(0, -1);
    return s;
  };

  const cleanProductQuery = (rest: string) => {
    const stopWords = ['rupee','rupees','price','at','for','each','unit','units','piece','pieces','per','of'];
    const words = normalizeName(rest).split(' ').filter(Boolean);
    const idx = words.findIndex(w => stopWords.includes(w));
    const trimmed = (idx !== -1 ? words.slice(0, idx) : words).join(' ');
    return singularize(trimmed).trim();
  };

  const findInventoryItem = (query: string): InventoryItem | undefined => {
    const q = singularize(normalizeName(query));
    // exact first
    let found = inventory.find(i => singularize(normalizeName(i.name)) === q);
    if (found) return found;
    // startsWith/contains fallback
    found = inventory.find(i => singularize(normalizeName(i.name)).startsWith(q) || q.startsWith(singularize(normalizeName(i.name))));
    if (found) return found;
    // includes fallback
    return inventory.find(i => singularize(normalizeName(i.name)).includes(q));
  };

  const verbs = ['sell','sale','sold','selling','cell','sail','tell'];

  // Parse a number from tokens starting at index (supports "12", "12.5", "twelve", "twenty five", "twelve point five")
  const parseNumberFromTokens = (tokens: string[], start: number): number | null => {
    const t0 = tokens[start];
    if (!t0) return null;
    // direct number or decimal
    if (/^\d+(\.\d+)?$/.test(t0)) return parseFloat(t0);
    let base = toNumber(t0);
    if (base === null) return null;
    // composite like "twenty five"
    if (start + 1 < tokens.length && base >= 20 && base % 10 === 0) {
      const next = toNumber(tokens[start + 1]);
      if (next !== null && next < 10) {
        base += next;
      }
    }
    // decimals with "point"
    if (tokens[start + 1] === 'point') {
      const decToken = tokens[start + 2];
      if (decToken) {
        if (/^\d+$/.test(decToken)) {
          return parseFloat(`${base}.${decToken}`);
        }
        const decWord = toNumber(decToken);
        if (decWord !== null && decWord < 10) {
          return parseFloat(`${base}.${decWord}`);
        }
      }
    }
    return base;
  };

  // Extract unit price from tokens after quantity using markers and currency hints
  const findUnitPrice = (tokens: string[], sourceText?: string): number | null => {
    const markers = new Set(['at','for','price','rupee','rupees','each','per','unit','units','piece','pieces','rs','rs.','inr','₹']);
    for (let i = 0; i < tokens.length; i++) {
      const t = tokens[i];
      if (markers.has(t)) {
        // look ahead for number patterns
        for (let j = 1; j <= 3 && i + j < tokens.length; j++) {
          const val = parseNumberFromTokens(tokens, i + j);
          if (val !== null) return val;
        }
      }
      // currency-first like "₹ 12" or "rs 12"
      if (t === '₹' || t === 'rs' || t === 'rs.' || t === 'inr') {
        const val = parseNumberFromTokens(tokens, i + 1);
        if (val !== null) return val;
      }
      // inline decimal number
      if (/^\d+(\.\d+)?$/.test(t)) {
        const prev = tokens[i - 1];
        if (prev && markers.has(prev)) return parseFloat(t);
      }
    }
    // Regex fallback on full text for currency amounts
    if (sourceText) {
      const m = sourceText.match(/(?:₹|rs\.?|inr)\s*(\d+(?:\.\d+)?)/i);
      if (m) return parseFloat(m[1]);
    }
    return null;
  };
  const parseVoiceSale = (command: string) => {
    const text = normalizeName(command);
    console.log('[SalesTab Voice] Heard:', text);

    // Check if command contains a selling verb
    if (!verbs.some(v => text.includes(v))) {
      toast({ title: 'Command not recognized', description: 'Try: "sell 5 pens"', variant: 'destructive' });
      return;
    }

    const tokens = text.split(' ').filter(Boolean);

    // Find quantity in the command (supports numbers and word numbers)
    let qtyIdx = -1;
    let qty = 0;

    for (let i = 0; i < tokens.length; i++) {
      const num = toNumber(tokens[i]);
      if (num !== null) {
        qtyIdx = i;
        qty = num;
        // composite numbers like "twenty five"
        if (i + 1 < tokens.length && qty >= 20 && qty % 10 === 0) {
          const nextNum = toNumber(tokens[i + 1]);
          if (nextNum !== null && nextNum < 10) {
            qty += nextNum;
            qtyIdx = i + 1;
          }
        }
        break;
      }
    }

    if (qtyIdx === -1 || qty <= 0) {
      toast({ title: 'Quantity not recognized', description: 'Say a number like "5" or "ten"', variant: 'destructive' });
      return;
    }

    console.log('[SalesTab Voice] Quantity found:', qty);

    const afterQtyTokens = tokens.slice(qtyIdx + 1);
    const afterQty = afterQtyTokens.join(' ');
    const productQuery = cleanProductQuery(afterQty);

    const unitPrice = findUnitPrice(afterQtyTokens, text);
    console.log('[SalesTab Voice] Product query:', productQuery, 'Unit price:', unitPrice);

    if (!productQuery) {
      toast({ title: 'Product not recognized', description: 'Say the product name after quantity', variant: 'destructive' });
      return;
    }

    processSale(productQuery, qty, unitPrice ?? undefined);
  };
  const toggleVoiceInput = async () => {
    if (isListening) {
      // Stop recording
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setIsListening(false);
      toast({ title: 'Stopped listening' });
    } else {
      try {
        // Start recording
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioChunksRef.current = [];
        
        const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
        mediaRecorderRef.current = mediaRecorder;

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };

        mediaRecorder.onstop = async () => {
          console.log('[SalesTab Voice] Recording stopped, processing...');
          stream.getTracks().forEach(track => track.stop());
          
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          
          // Convert to base64
          const reader = new FileReader();
          reader.onloadend = async () => {
            const base64Audio = (reader.result as string).split(',')[1];
            
            try {
              // Send to SambaNova Whisper via edge function
              const { supabase } = await import('@/integrations/supabase/client');
              const { data, error } = await supabase.functions.invoke('transcribe-audio', {
                body: { audio: base64Audio }
              });

              if (error) throw error;

              const transcription = data.text.toLowerCase().trim();
              console.log('[SalesTab Voice] Transcription:', transcription);
              setLastHeard(transcription);
              parseVoiceSale(transcription);
              
            } catch (error) {
              console.error('[SalesTab Voice] Transcription error:', error);
              toast({ 
                title: 'Transcription failed', 
                description: 'Could not process audio',
                variant: 'destructive' 
              });
            }
          };
          
          reader.readAsDataURL(audioBlob);
        };

        mediaRecorder.start();
        setIsListening(true);
        toast({ title: 'Listening…', description: 'Say: "sell 5 pens"' });

        // Auto-stop after 8 seconds
        setTimeout(() => {
          if (mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            setIsListening(false);
          }
        }, 8000);

      } catch (error: any) {
        console.error('[SalesTab Voice] Microphone error:', error);
        toast({ 
          title: 'Microphone error', 
          description: error.message || 'Could not access microphone',
          variant: 'destructive' 
        });
        setIsListening(false);
      }
    }
  };

  const processSale = (productName: string, qty: number, spokenPrice?: number) => {
    console.log('[SalesTab] Processing sale:', { productName, qty, spokenPrice, inventoryCount: inventory.length });
    const item = findInventoryItem(productName);
    console.log('[SalesTab] Item found:', item);

    if (!item) {
      toast({ title: 'Product not found', description: `"${productName}" is not in inventory. Add it first.`, variant: 'destructive' });
      return;
    }

    if (item.quantity < qty) {
      toast({ title: 'Insufficient stock', description: `Only ${item.quantity} ${item.name} available`, variant: 'destructive' });
      return;
    }

    // Use spoken price if provided, otherwise use inventory price
    const unitPrice = spokenPrice ?? item.price;
    
    // Block ONLY if both spoken price and inventory price are missing/zero
    if (unitPrice <= 0) {
      toast({ 
        title: 'Price not set', 
        description: `${item.name} has no price. Either add price to inventory or say: "sell ${qty} ${item.name} at 10 rupees"`, 
        variant: 'destructive' 
      });
      return;
    }

    const saleRecord: SaleRecord = {
      id: Date.now().toString(),
      product: item.name,
      quantity: qty,
      price: unitPrice,
      total: qty * unitPrice,
      timestamp: new Date().toISOString()
    };

    setSalesHistory(prev => [saleRecord, ...prev]);

    const updatedInventory = inventory.map(i =>
      i.id === item.id ? { ...i, quantity: i.quantity - qty } : i
    );
    setInventory(updatedInventory);
    if (user) {
      localStorage.setItem(`inventory_${user.id}`, JSON.stringify(updatedInventory));
    }

    toast({ title: 'Sale recorded', description: `Sold ${qty} ${item.name} for ₹${saleRecord.total}` });
    setProduct('');
    setQuantity('');
  };

  const handleManualSale = () => {
    if (!product || !quantity) {
      toast({ title: 'Missing fields', description: 'Enter product and quantity', variant: 'destructive' });
      return;
    }
    processSale(product, parseInt(quantity));
  };

  const todayTotal = salesHistory
    .filter(s => new Date(s.timestamp).toDateString() === new Date().toDateString())
    .reduce((sum, s) => sum + s.total, 0);

  return (
    <>
      <Card className="glass-effect hover-lift border-secondary/30 shadow-glow">
        <CardHeader className="gradient-secondary text-white rounded-t-xl">
          <CardTitle className="flex items-center gap-3 text-2xl">
            <TrendingUp className="w-8 h-8" />
            Today's Sales
          </CardTitle>
          <CardDescription className="text-4xl font-bold text-white mt-2">₹{todayTotal.toLocaleString('en-IN')}</CardDescription>
        </CardHeader>
      </Card>

      <Card className="glass-effect hover-lift border-primary/20">
        <CardHeader className="bg-gradient-to-r from-accent/10 to-transparent">
          <CardTitle className="text-xl">Record Sale</CardTitle>
          <CardDescription>Record sales manually or via voice</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 pt-6">
          <div className="flex items-center gap-3">
            <Button
              onClick={toggleVoiceInput}
              variant={isListening ? 'destructive' : 'default'}
              className={`w-full sm:w-auto shadow-elegant ${isListening ? 'pulse shadow-glow' : ''}`}
            >
              {isListening ? <MicOff className="w-5 h-5 mr-2" /> : <Mic className="w-5 h-5 mr-2" />}
              {isListening ? 'Stop Voice Input' : 'Start Voice Input'}
            </Button>
            {isListening && (
              <div className="flex items-center gap-2 text-primary">
                <div className="w-3 h-3 rounded-full bg-primary shadow-glow pulse" />
                <span className="text-sm">Listening…</span>
              </div>
            )}
          </div>
          {lastHeard && <p className="text-xs text-muted-foreground mt-1">Heard: "{lastHeard}"</p>}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="product" className="text-sm font-semibold">Product Name</Label>
              <Input
                id="product"
                placeholder="e.g., Pen"
                value={product}
                onChange={(e) => setProduct(e.target.value)}
                className="border-2 focus:border-secondary transition-colors"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="saleQty" className="text-sm font-semibold">Quantity</Label>
              <Input
                id="saleQty"
                type="number"
                placeholder="e.g., 5"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="border-2 focus:border-secondary transition-colors"
              />
            </div>
          </div>

          <Button onClick={handleManualSale} className="w-full gradient-secondary text-white shadow-glow hover:scale-105 transition-transform">
            <TrendingUp className="w-5 h-5 mr-2" />
            Record Sale
          </Button>
        </CardContent>
      </Card>

      <Card className="glass-effect hover-lift border-accent/20">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-transparent">
          <CardTitle className="text-xl">Recent Sales</CardTitle>
          <CardDescription className="text-lg font-semibold text-foreground">{salesHistory.length} transactions</CardDescription>
        </CardHeader>
        <CardContent>
          {salesHistory.length === 0 ? (
            <div className="text-center py-12">
              <TrendingUp className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No sales recorded yet</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
              {salesHistory.map((sale, idx) => (
                <div
                  key={sale.id}
                  className="p-4 rounded-xl border-2 bg-gradient-to-r from-card to-secondary/5 hover:shadow-elegant hover:-translate-y-0.5 transition-all duration-300"
                  style={{ animationDelay: `${idx * 0.05}s` }}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <p className="font-bold text-lg text-foreground">{sale.product}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        <span className="font-semibold text-foreground">{sale.quantity}</span> × 
                        <span className="font-semibold text-secondary"> ₹{sale.price}</span> = 
                        <span className="font-bold text-accent text-lg ml-1">₹{sale.total}</span>
                      </p>
                    </div>
                    <p className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-lg">
                      {new Date(sale.timestamp).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
};

export default SalesTab;
