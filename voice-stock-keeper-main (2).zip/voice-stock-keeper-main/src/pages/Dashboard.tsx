import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/integrations/supabase/auth';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { LogOut, Package } from 'lucide-react';
import InventoryTab from '@/components/dashboard/InventoryTab';
import SalesTab from '@/components/dashboard/SalesTab';
import ReportsTab from '@/components/dashboard/ReportsTab';
import ProfileTab from '@/components/dashboard/ProfileTab';
import AnalyticsTab from '@/components/dashboard/AnalyticsTab';

const Dashboard = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/auth');
    }
  }, [user, navigate]);

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <header className="border-b bg-card/80 backdrop-blur-lg sticky top-0 z-10 shadow-elegant">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 gradient-primary rounded-2xl shadow-glow transition-transform hover:scale-110">
              <Package className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
                Inventory Pro
              </h1>
              <p className="text-sm text-muted-foreground font-medium">Voice-Enabled Management System</p>
            </div>
          </div>
          <Button onClick={signOut} variant="outline" size="sm" className="hover-lift border-2">
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="inventory" className="space-y-8">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid p-1.5 bg-muted/50 backdrop-blur-sm h-auto gap-2">
            <TabsTrigger value="inventory" className="data-[state=active]:gradient-primary data-[state=active]:text-white data-[state=active]:shadow-glow transition-all">
              Inventory
            </TabsTrigger>
            <TabsTrigger value="sales" className="data-[state=active]:gradient-secondary data-[state=active]:text-white data-[state=active]:shadow-glow transition-all">
              Sales
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:gradient-accent data-[state=active]:text-white data-[state=active]:shadow-glow transition-all">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="reports" className="data-[state=active]:gradient-accent data-[state=active]:text-white data-[state=active]:shadow-glow transition-all">
              Reports
            </TabsTrigger>
            <TabsTrigger value="profile" className="data-[state=active]:gradient-primary data-[state=active]:text-white data-[state=active]:shadow-glow transition-all">
              Profile
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inventory" className="space-y-4 animate-in fade-in-50 duration-300">
            <InventoryTab />
          </TabsContent>

          <TabsContent value="sales" className="space-y-4 animate-in fade-in-50 duration-300">
            <SalesTab />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4 animate-in fade-in-50 duration-300">
            <AnalyticsTab />
          </TabsContent>

          <TabsContent value="reports" className="space-y-4 animate-in fade-in-50 duration-300">
            <ReportsTab />
          </TabsContent>

          <TabsContent value="profile" className="space-y-4 animate-in fade-in-50 duration-300">
            <ProfileTab />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Dashboard;
