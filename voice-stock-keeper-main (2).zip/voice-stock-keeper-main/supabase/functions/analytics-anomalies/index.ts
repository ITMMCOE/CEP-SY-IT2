import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SaleRecord {
  product: string;
  quantity: number;
  timestamp: string;
  total: number;
}

interface Anomaly {
  type: 'spike' | 'drop' | 'unusual_pattern';
  item: string;
  description: string;
  timestamp: string;
  severity: 'low' | 'medium' | 'high';
  value: number;
  expected: number;
}

// Calculate Z-score for anomaly detection
function calculateZScore(value: number, mean: number, stdDev: number): number {
  if (stdDev === 0) return 0;
  return (value - mean) / stdDev;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { salesHistory } = await req.json() as { salesHistory: SaleRecord[] };

    if (!salesHistory || salesHistory.length < 7) {
      return new Response(
        JSON.stringify({ anomalies: [], message: 'Not enough data for anomaly detection (need at least 7 sales)' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const anomalies: Anomaly[] = [];

    // Group sales by product
    const salesByProduct = salesHistory.reduce((acc, sale) => {
      if (!acc[sale.product]) acc[sale.product] = [];
      acc[sale.product].push(sale);
      return acc;
    }, {} as Record<string, SaleRecord[]>);

    // Analyze each product for anomalies
    for (const [product, sales] of Object.entries(salesByProduct)) {
      if (sales.length < 5) continue; // Need minimum data

      // Sort by date
      const sortedSales = sales.sort((a, b) => 
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );

      const quantities = sortedSales.map(s => s.quantity);
      const totals = sortedSales.map(s => s.total);

      // Calculate statistics
      const meanQty = quantities.reduce((a, b) => a + b, 0) / quantities.length;
      const meanTotal = totals.reduce((a, b) => a + b, 0) / totals.length;

      const varianceQty = quantities.reduce((sum, q) => sum + Math.pow(q - meanQty, 2), 0) / quantities.length;
      const varianceTotal = totals.reduce((sum, t) => sum + Math.pow(t - meanTotal, 2), 0) / totals.length;

      const stdDevQty = Math.sqrt(varianceQty);
      const stdDevTotal = Math.sqrt(varianceTotal);

      // Check last 3 sales for anomalies
      const recentSales = sortedSales.slice(-3);

      for (const sale of recentSales) {
        const qtyZScore = calculateZScore(sale.quantity, meanQty, stdDevQty);
        const totalZScore = calculateZScore(sale.total, meanTotal, stdDevTotal);

        // Spike detection (Z-score > 2)
        if (qtyZScore > 2) {
          anomalies.push({
            type: 'spike',
            item: product,
            description: `Unusual sales spike detected for ${product}. Sold ${sale.quantity} units (${Math.round(qtyZScore * 100)}% above average)`,
            timestamp: sale.timestamp,
            severity: qtyZScore > 3 ? 'high' : 'medium',
            value: sale.quantity,
            expected: Math.round(meanQty)
          });
        }

        // Drop detection (Z-score < -2)
        if (qtyZScore < -2) {
          anomalies.push({
            type: 'drop',
            item: product,
            description: `Unusual sales drop for ${product}. Only ${sale.quantity} units sold (${Math.round(Math.abs(qtyZScore) * 100)}% below average)`,
            timestamp: sale.timestamp,
            severity: qtyZScore < -3 ? 'high' : 'medium',
            value: sale.quantity,
            expected: Math.round(meanQty)
          });
        }

        // Unusual pattern: high quantity but low total (price issue?)
        if (qtyZScore > 1 && totalZScore < -1) {
          anomalies.push({
            type: 'unusual_pattern',
            item: product,
            description: `Possible pricing issue for ${product}. High quantity (${sale.quantity}) but lower than expected revenue (₹${sale.total})`,
            timestamp: sale.timestamp,
            severity: 'low',
            value: sale.total,
            expected: Math.round(meanTotal)
          });
        }
      }
    }

    // Sort by severity and timestamp
    const severityOrder = { high: 0, medium: 1, low: 2 };
    anomalies.sort((a, b) => {
      const severityDiff = severityOrder[a.severity] - severityOrder[b.severity];
      if (severityDiff !== 0) return severityDiff;
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });

    return new Response(
      JSON.stringify({ anomalies: anomalies.slice(0, 10) }), // Return top 10
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Anomaly detection error:', error);
    const message = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
