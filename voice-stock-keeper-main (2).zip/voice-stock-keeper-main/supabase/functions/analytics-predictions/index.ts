import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SaleRecord {
  product: string;
  quantity: number;
  timestamp: string;
}

interface InventoryItem {
  name: string;
  quantity: number;
  price: number;
}

interface Prediction {
  item: string;
  currentStock: number;
  daysUntilEmpty: number;
  confidence: number;
  suggestedRestock: number;
  restockBy: string;
}

// Simple linear regression for stock depletion prediction
function linearRegression(data: number[]): { slope: number; intercept: number } {
  const n = data.length;
  if (n < 2) return { slope: 0, intercept: data[0] || 0 };

  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  
  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += data[i];
    sumXY += i * data[i];
    sumX2 += i * i;
  }
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  
  return { slope, intercept };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { salesHistory, inventory } = await req.json() as { 
      salesHistory: SaleRecord[]; 
      inventory: InventoryItem[] 
    };

    if (!salesHistory || !inventory) {
      return new Response(
        JSON.stringify({ error: 'Missing salesHistory or inventory data' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const predictions: Prediction[] = [];
    const today = new Date();

    // Group sales by product
    const salesByProduct = salesHistory.reduce((acc, sale) => {
      if (!acc[sale.product]) acc[sale.product] = [];
      acc[sale.product].push(sale);
      return acc;
    }, {} as Record<string, SaleRecord[]>);

    // Analyze each inventory item
    for (const item of inventory) {
      const productSales = salesByProduct[item.name] || [];
      
      if (productSales.length < 3) {
        // Not enough data for prediction
        continue;
      }

      // Sort sales by date (most recent first)
      const sortedSales = productSales
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 30); // Last 30 transactions

      // Calculate daily sales rate
      const quantities = sortedSales.map(s => s.quantity);
      const avgDailySales = quantities.reduce((a, b) => a + b, 0) / quantities.length;

      if (avgDailySales <= 0) continue;

      // Linear regression on sales trend
      const regression = linearRegression(quantities);
      const trend = regression.slope; // negative = decreasing sales, positive = increasing

      // Calculate days until stock runs out
      const adjustedSalesRate = avgDailySales * (1 + Math.abs(trend) * 0.1); // Adjust for trend
      const daysUntilEmpty = item.quantity / adjustedSalesRate;

      // Calculate confidence based on data consistency
      const variance = quantities.reduce((sum, q) => sum + Math.pow(q - avgDailySales, 2), 0) / quantities.length;
      const stdDev = Math.sqrt(variance);
      const confidence = Math.max(0, Math.min(100, 100 - (stdDev / avgDailySales) * 100));

      // Suggest restock amount and date
      const suggestedRestock = Math.ceil(avgDailySales * 14); // 2 weeks supply
      const restockDate = new Date(today);
      restockDate.setDate(today.getDate() + Math.max(0, Math.floor(daysUntilEmpty - 3)));

      predictions.push({
        item: item.name,
        currentStock: item.quantity,
        daysUntilEmpty: Math.round(daysUntilEmpty * 10) / 10,
        confidence: Math.round(confidence),
        suggestedRestock,
        restockBy: restockDate.toISOString().split('T')[0]
      });
    }

    // Sort by urgency (items running out soonest first)
    predictions.sort((a, b) => a.daysUntilEmpty - b.daysUntilEmpty);

    return new Response(
      JSON.stringify({ predictions }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Prediction error:', error);
    const message = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
