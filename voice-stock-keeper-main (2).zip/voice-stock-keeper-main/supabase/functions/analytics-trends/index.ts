import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SaleRecord {
  product: string;
  quantity: number;
  timestamp: string;
  total: number;
}

interface DailyTrend {
  date: string;
  totalSales: number;
  transactions: number;
  avgSaleValue: number;
}

interface ProductTrend {
  product: string;
  totalQuantity: number;
  totalRevenue: number;
  transactions: number;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { salesHistory } = await req.json() as { salesHistory: SaleRecord[] };

    if (!salesHistory || salesHistory.length === 0) {
      return new Response(
        JSON.stringify({ 
          dailyTrends: [], 
          topProducts: [],
          message: 'No sales data available' 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Group sales by date
    const salesByDate = salesHistory.reduce((acc, sale) => {
      const date = new Date(sale.timestamp).toISOString().split('T')[0];
      if (!acc[date]) {
        acc[date] = { totalSales: 0, transactions: 0, revenue: 0 };
      }
      acc[date].totalSales += sale.quantity;
      acc[date].transactions += 1;
      acc[date].revenue += sale.total;
      return acc;
    }, {} as Record<string, { totalSales: number; transactions: number; revenue: number }>);

    // Create daily trends (last 30 days)
    const dailyTrends: DailyTrend[] = Object.entries(salesByDate)
      .map(([date, data]) => ({
        date,
        totalSales: data.totalSales,
        transactions: data.transactions,
        avgSaleValue: Math.round(data.revenue / data.transactions)
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(-30);

    // Group by product for top sellers
    const productStats = salesHistory.reduce((acc, sale) => {
      if (!acc[sale.product]) {
        acc[sale.product] = { totalQuantity: 0, totalRevenue: 0, transactions: 0 };
      }
      acc[sale.product].totalQuantity += sale.quantity;
      acc[sale.product].totalRevenue += sale.total;
      acc[sale.product].transactions += 1;
      return acc;
    }, {} as Record<string, { totalQuantity: number; totalRevenue: number; transactions: number }>);

    // Top products by revenue
    const topProducts: ProductTrend[] = Object.entries(productStats)
      .map(([product, stats]) => ({
        product,
        totalQuantity: stats.totalQuantity,
        totalRevenue: stats.totalRevenue,
        transactions: stats.transactions
      }))
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .slice(0, 10);

    // Calculate simple moving average (SMA) for trend prediction
    const revenueData = dailyTrends.map(d => d.avgSaleValue);
    let sma7 = 0;
    if (revenueData.length >= 7) {
      sma7 = revenueData.slice(-7).reduce((a, b) => a + b, 0) / 7;
    }

    return new Response(
      JSON.stringify({ 
        dailyTrends,
        topProducts,
        insights: {
          totalRevenue: topProducts.reduce((sum, p) => sum + p.totalRevenue, 0),
          totalTransactions: salesHistory.length,
          avgTransactionValue: Math.round(salesHistory.reduce((sum, s) => sum + s.total, 0) / salesHistory.length),
          weeklyAverage: Math.round(sma7)
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Trends analysis error:', error);
    const message = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
